# necessaries
import sys
sys.path.append('/home/hongyu.shen/Models/')
import tensorflow as tf
import os
import math
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
from tensorflow.contrib import rnn
import matplotlib
matplotlib.use('Agg')

# dataset
#from dataset.dataset_GW_ import GWDataset_


# models
from models.multiRNNAE_multitime import multiLSTMAutoencoderMultiTime

# trainers
from trainers.trainer import  NoisyTrainerMultiTime

# initial settings
#dataset = GWDataset_(num_of_signals=901, expected_seconds=0.15, sample_rate=1300,
#                     make_multiple_timesteps=False, seq_len_per_timestep=9)

model = multiLSTMAutoencoderMultiTime(hidden_num=[64, 64], dataset=dataset, name='model_name', batch_size=30,
                                cell=[rnn.LSTMCell], learning_rate=0.001, latent_dim=128, seq_len_per_timestep=9)


trainer = NoisyTrainerMultiTime(model, dataset, SNR=1.5, denoise=True)

trainer.train(single_image_draw_index=170,iterations=100000)