from visualization.visualize import NoiseAEMultiTimeImageVisualizer
import time
import numpy as np
from sklearn.preprocessing import scale
import random


    
    
class NoisyTrainerMultiTime:
    def __init__(self, network, dataset, SNR=20., denoise=True):
        self.network = network
        self.dataset = dataset
        self.batch_size = network.batch_size
        self.data_dims = self.dataset.data_dims
        self.train_with_mask = False
        self.train_discrete = False
        self.train_size = self.dataset.train_size
        self.fig, self.ax = None, None
        self.SNR = SNR
        self.denoise_train = denoise


    def train(self, single_image_draw_index=0, iterations=500):
        single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
        iteration = 0
        
        maxpoint = self.get_noisy_input(self.dataset.next_batch(self.batch_size)).max()
        minpoint = self.get_noisy_input(self.dataset.next_batch(self.batch_size)).min()
        
        while iteration < iterations:
            
            if iteration == 2000:
                self.SNR = 1.2
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 3000:
                self.SNR = 1.0
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 4500:
                self.SNR = .9
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 6000:
                self.SNR = .8
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 7500:
                self.SNR = .7
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 9000:
                self.SNR = .6
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 10500:
                self.SNR = .5
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
              
            if iteration == 13500:
                self.SNR = .4
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
                
            if iteration == 15000:
                self.SNR = .3
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            '''

            if iteration == 2000:
                self.SNR = 1.5
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 3000:
                self.SNR = 1.4
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 4500:
                self.SNR = 1.3
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 6000:
                self.SNR = 1.2
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 7500:
                self.SNR = 1.1
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 9000:
                self.SNR = 1.
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 10500:
                self.SNR = .9
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 13000:
                self.SNR = .8
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            if iteration == 14500:
                self.SNR = .7
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)           
            if iteration == 16000:
                self.SNR = .6
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR) 
            if iteration == 17500:
                self.SNR = .5
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR) 
            if iteration == 25000:
                self.SNR = .4
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)   
            if iteration == 35000:
                self.SNR = .3
                single_image_visualizer = NoiseAEMultiTimeImageVisualizer(self.network, self.dataset, index=single_image_draw_index, SNR=self.SNR)
            '''
            
            iter_time = time.time() # count time
            images = self.dataset.next_batch(self.batch_size) # get batches
            images = self.standardize_amp(images)
            
            #####
            # choose to shift data
            #####
            
            if True:
                images = self.shift_data(images)
                
            
            
            images_ = np.vstack((images, np.zeros(images.shape))) # combine true signal and noise

            ## generate labels
            #labels  = np.hstack((np.zeros([1,self.batch_size]), np.ones([1,self.batch_size]))) # genrate labels 
            #labels = self.to_categorical(labels).astype(np.float32)

            noisy_input = self.get_noisy_input(images_) # add noise to signal and zeros
            #noisy_input = self.scale_data_(noisy_input, minpoint, maxpoint)
            #images_ = self.scale_data_(images_, minpoint, maxpoint)
            
            
            stds = np.std(noisy_input, axis=1)[np.newaxis].transpose()
            noisy_input = noisy_input / stds
            
            
            multitime_noisy_input = self.make_multi(noisy_input)
            #noisy_input = scale(noisy_input, 1) # rescale it to have variance one
            #images = np.vstack((images, np.zeros(images.shape)))
            
            
            #if classes_index is True:
            #train_loss = self.network.train_cls(noisy_input, images, labels)
            #train_loss, reg_loss, regressions = self.network.train_reg(noisy_input, images_reg, labels, mass_reg)
            #l_df, l_dr, l_g, l_e, l_dis = self.network.train_cls_gan(noisy_input, images, labels)
            #else:
            train_loss = self.network.train(images_ / stds, multitime_noisy_input)

            if iteration % 50 == 0:
                print("Iteration %d: Reconstruction loss %f, time per iter %fs" %
                      (iteration, train_loss, time.time() - iter_time))
                #print("Reg Loss: %f" % (reg_loss))
                #print(regressions[:10])
                #print("Discriminator Loss: %f for real and %f for fake" % (l_dr, l_df))
                #print("Generator Loss: %f" % (l_g))
                #print("VAE Loss: %f" % (l_e))
                
                #if visualization == 'nosqueeze':
                #    single_image_visualizer_nosqueeze.visualize()
                #else:
                single_image_visualizer.visualize(train_loss)

            iteration += 1
            
    def get_noisy_input(self, original):
        if not self.denoise_train:
            return original

        # Add salt and pepper noise
        # noisy_input = np.multiply(original, np.random.binomial(n=1, p=0.9, size=[self.batch_size]+self.data_dims)) + \
        #               np.random.binomial(n=1, p=0.1, size=[self.batch_size]+self.data_dims)

        # Add Gaussian noise
        noisy_input = original + np.random.normal(0,1./self.SNR,original.shape)
        #print(noisy_input.shape)
        #plt.plot(noisy_input)
        #plt.show()


        return noisy_input
    
    
    def make_multi(self, inputs):
        dataFile = inputs
        #print(self.network.seq_len_per_timestep)
        num_of_zeros = (self.network.seq_len_per_timestep - 1) / 2
        extended_dims = [inputs.shape[0], inputs.shape[1], ] + [self.network.seq_len_per_timestep]
        tmpFile = np.zeros(extended_dims)
        #for k in range(self.data_dims[0]):
        for k in range(inputs.shape[0]):
            for i in range(inputs.shape[1]):
            #for i in range(self.data_dims[-2]):
                if i < num_of_zeros:
                    tmpFile[k, i, :] = np.hstack((np.zeros([num_of_zeros-i]),
                                                  dataFile[k, :(self.network.seq_len_per_timestep-num_of_zeros+i)]))
                elif i >= num_of_zeros and i < (inputs.shape[1]-num_of_zeros-1):
                    tmpFile[k, i, :] = dataFile[k, (i-num_of_zeros):(i + num_of_zeros + 1)]    
                elif i > (inputs.shape[1]-num_of_zeros-1):
                    #print(dataFile[k, (i-num_of_zeros):].shape)
                    #print(np.zeros([num_of_zeros-(self.data_dims[-2]-1-i)]).shape)
                    tmpFile[k, i, :] = np.hstack((dataFile[k, (i-num_of_zeros):], 
                                                          np.zeros([num_of_zeros-(inputs.shape[1]-1-i)])))
        return tmpFile
    
    
    def scale_data_(self, inputs, datamin, datamax):
        data_std = (inputs - datamin) / (datamax - datamin)
        outputs = data_std * (0.99 - (0.01)) + (0.01)
        return outputs

        
    def rescale_data_(self, inputs, datamin, datamax):
        data_std = (inputs - inputs.min()) / (inputs.max() - inputs.min())
        data_rescaled = data_std * (datamax - datamin) + datamin
        outputs = data_rescaled
        return outputs
    
    
    def shift_data(self, inputs):
        if len(inputs.shape) == 1:
            inputs = inputs[np.newaxis]
        for i in range(inputs.shape[0]):
            shift_int = np.random.randint(1, 200, size=1, dtype=np.int)
            zero_vecs = np.zeros([1, inputs.shape[1]])
            zero_vecs[:, :-shift_int[0]] = inputs[i, shift_int[0]:]
            inputs[i, :] = zero_vecs[:,:]
        return inputs
    
    def standardize_amp(self, inputs):
        reduce_dim = False
        if len(inputs.shape) == 1:
            inputs = inputs[np.newaxis]
            reduce_dim = True
        max_values = inputs.max(axis=1)
        outputs = np.multiply(inputs, 1. / max_values[:, np.newaxis])
        if reduce_dim is True:
            return np.squeeze(outputs, axis=0)
        else:
            return outputs
    




