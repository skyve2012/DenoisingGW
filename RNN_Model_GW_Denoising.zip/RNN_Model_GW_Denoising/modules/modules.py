import tensorflow as tf
import numpy as np
import math
import glob
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
#get_ipython().magic(u'matplotlib inline')
from matplotlib.patches import Ellipse
from tensorflow.examples.tutorials.mnist import input_data
import os, sys, shutil, re
from tensorflow.contrib import rnn
import tensorflow.contrib.slim as slim
import random
from sklearn.preprocessing import scale
import random
# the basic network structure contains basic save and restore functions 

class Network:
    def __init__(self, dataset, batch_size):
        self.dataset = dataset
        self.batch_size = batch_size
        self.learning_rate_placeholder = tf.placeholder(shape=[], dtype=tf.float32, name="lr_placeholder")

        gpu_options = tf.GPUOptions(allow_growth=True)
        self.sess = tf.InteractiveSession(config=tf.ConfigProto(gpu_options=gpu_options, allow_soft_placement=True))
        # A unique name should be given to each instance of subclasses during initialization
        self.name = "default"

        # These should be updated accordingly
        self.iteration = 0
        self.learning_rate = 0.0
        self.read_only = False

        self.do_generate_samples = False
        self.do_generate_conditional_samples = False
        self.do_generate_manifold_samples = False
        #self.writer = tf.summary.FileWriter("models/" + self.name, self.sess.graph)

    def make_model_path(self):
        if not os.path.isdir("models"):
            os.mkdir("models")
        if not os.path.isdir("models/" + self.name):
            os.mkdir("models/" + self.name)

    def print_network(self):
        self.make_model_path()
        if os.path.isdir("models/" + self.name):
            for f in os.listdir("models/" + self.name):
                if re.search(r"events.out*", f):
                    os.remove(os.path.join("models/" + self.name, f))
        self.writer = tf.summary.FileWriter("models/" + self.name, self.sess.graph)
        self.writer.flush()

    """ Save network, if network file already exists back it up to models/old folder. Only one back up will be created
    for each network """
    def save_network(self):
        if not self.read_only:
            # Saver and Summary ops cannot run in GPU
            with tf.device('/cpu:0'):
                saver = tf.train.Saver()
            self.make_model_path()
            if not os.path.isdir("models/old"):
                os.mkdir("models/old")
            file_name = "models/" + self.name + "/" + self.name + ".ckpt"
            if os.path.isfile(file_name):
                os.rename(file_name, "models/old/" + self.name + ".ckpt")
            saver.save(self.sess, file_name)

    """ Either initialize or load network from file.
    Always run this at end of initialization for every subclass to initialize Variables properly """
    def init_network(self, restart=False):
        self.sess.run(tf.global_variables_initializer())
        if restart:
            return
        file_name = "models/" + self.name + "/" + self.name + ".ckpt"
        if len(glob.glob(file_name + '*')) != 0:
            saver = tf.train.Saver()
            try:
                saver.restore(self.sess, file_name)
            except:
                print("Warning: network load failed, reinitializing all variables", sys.exc_info()[0])
                self.sess.run(tf.global_variables_initializer())
        else:
            print("No checkpoint file found, Initializing model from random")

    """ This function should train on the given batch and return the training loss """
    def train(self, batch_input, batch_target, labels=None):
        return None

    """ This function should take the input and return the reconstructed images """
    def test(self, batch_input, labels=None):
        return None
    
    def restore_network(self, var_dict=None, train_vars=None):
        assert isinstance(self.restore_path, str)
        assert self.restore_path is not None
        
        if var_dict is None:
            saver = tf.train.Saver()
            saver.restore(self.sess, tf.train.latest_checkpoint(self.restore_path))
        else:
            assert train_vars is not None
            saver = tf.train.Saver(var_dict)
            #print(var_dict)
            saver.restore(self.sess, tf.train.latest_checkpoint(self.restore_path))
            tf.variables_initializer(train_vars)


    
# contains some small functions

class network_functions(Network):
    def __init__(self, dataset, batch_size):
        Network.__init__(self, dataset, batch_size)
        
    ##########
    # scale data to between 0 and 1
    ##########
    
    def scale_data_(self, inputs, datamin, datamax):
        data_std = (inputs - datamin) / (datamax - datamin)
        outputs = data_std * (0.99 - (0.01)) + (0.01)
        return outputs
    
    ##########
    # rescale data back
    ##########

        
    def rescale_data_(self, inputs, datamin, datamax):
        data_std = (inputs - inputs.min()) / (inputs.max() - inputs.min())
        data_rescaled = data_std * (datamax - datamin) + datamin
        outputs = data_rescaled
        return outputs
      
    ##########
    # activation funciton: lrelu
    
    def lrelu(self, x, leak=0.02, name="lrelu"):
        ''' Leaky ReLU '''
        return tf.maximum(x, leak*x)
    
    
    ##########
    #make multi time for denoising 
    ##########
    
    def make_multi(self, inputs):
        dataFile = inputs
        #print(self.network.seq_len_per_timestep)
        num_of_zeros = (self.seq_len_per_timestep - 1) / 2
        extended_dims = [inputs.shape[0], inputs.shape[1], ] + [self.seq_len_per_timestep]
        tmpFile = np.zeros(extended_dims)
        for k in range(inputs.shape[0]):
            for i in range(inputs.shape[1]):
                if i < num_of_zeros:
                    tmpFile[k, i, :] = np.hstack((np.zeros([num_of_zeros-i]),
                                                  dataFile[k, :(self.seq_len_per_timestep-num_of_zeros+i)]))
                elif i >= num_of_zeros and i < (inputs.shape[1]-num_of_zeros-1):
                    tmpFile[k, i, :] = dataFile[k, (i-num_of_zeros):(i + num_of_zeros + 1)]    
                elif i > (inputs.shape[1]-num_of_zeros-1):
                    #print(dataFile[k, (i-num_of_zeros):].shape)
                    #print(np.zeros([num_of_zeros-(self.data_dims[-2]-1-i)]).shape)
                    tmpFile[k, i, :] = np.hstack((dataFile[k, (i-num_of_zeros):], 
                                                          np.zeros([num_of_zeros-(inputs.shape[1]-1-i)])))
        return tmpFile
    
    
    ##########
    # Guassian Sampler for VAE latent layer to output samples
    ##########
    
    def GaussianSampler(self, z_mean, z_logvar, name='GaussianSampleLayer'):
        with tf.name_scope(name):
            eps = tf.random_normal([tf.stack(tf.shape(z_mean)[0]), z_mean.get_shape().as_list()[-1]])
            std = tf.sqrt(tf.exp(z_logvar))
        return tf.add(z_mean, tf.multiply(eps, std))
    
    ##########
    # Reshape the random gaussian samples
    ##########
    def reshape_gaussian(self, inputs, name=None):
        assert isinstance(name, str) is True

        with tf.variable_scope(name):
            with slim.arg_scope(
                [slim.fully_connected],
                normalizer_fn=slim.batch_norm,
                weights_initializer=tf.random_normal_initializer(0.,.8),
                biases_initializer=tf.constant_initializer(.3),
                activation_fn=tf.nn.tanh):
                outputs = slim.fully_connected(inputs, self.sample_rate)
                outputs = tf.expand_dims(outputs, axis=-1)
        return outputs
    
    
    ##########
    # KLD
    ##########
    
    def KLD(self, mean, var):
        loss = tf.reduce_sum(-tf.log(tf.sqrt(tf.exp(var))) + 0.5 * tf.exp(var) +
                                            0.5 * tf.square(mean) - 0.5, keep_dims=False) / self.batch_size
        return loss
    
    
    
    ##########
    #normalize data
    ##########
    def standardize_amp(self, inputs):
        reduce_dim = False
        if len(inputs.shape) == 1:
            inputs = inputs[np.newaxis]
            reduce_dim = True
        max_values = inputs.max(axis=1)
        outputs = np.multiply(inputs, 1. / max_values[:, np.newaxis])
        if reduce_dim is True:
            return np.squeeze(outputs, axis=0)
        else:
            return outputs
    

        

    
    
    ##########
    # generate training samples
    ##########
    def generate_sample(self, index=0, SNR=2., target=None):
        assert target is not None
               
        def shift_data(inputs):
            #direction = np.random.randint(1,3,size=1,dtype=np.int)
            if len(inputs.shape) == 1:
                inputs = inputs[np.newaxis]
            for i in range(inputs.shape[0]):
                shift_int = np.random.randint(1, 200, size=1, dtype=np.int)
                zero_vecs = np.zeros([1, inputs.shape[1]])
                zero_vecs[:, :-shift_int[0]] = inputs[i, shift_int[0]:]
                inputs[i, :] = zero_vecs[:,:]        
            return inputs
        
        if target == 'new':
            index_ = random.randint(0, index)
            original = self.dataset.test_img[index_, :][np.newaxis]
            noise = np.random.normal(0,1./SNR, original.shape)
            noisySignal = original + noise
            #noise = scale(noise, 1)
            #original = scale(original, 1)
            feed_value = {self.x_original_placeholder: original,
                          self.x_noise_placeholder: np.random.normal(0,1./SNR, original.shape),
                          self.x_noisySignal_placeholder: noisySignal}
            denoised = self.sess.run(self.original_outputs, feed_dict=feed_value)
            noisySignal_ = self.sess.run(self.noisySignal_outputs, feed_dict=feed_value)

            return original, denoised, noisySignal_, noisySignal
        
        
    
        if target == 'NoiseAE':
            index_ = random.randint(0, index)
            original = self.dataset.test_img[index_, :][np.newaxis] 
            noise = original + np.random.normal(0,1./SNR, original.shape)
            feed_value = {self.x_original_placeholder: original, self.x_noise: noise}
            feed_value1 = {self.x_original_placeholder: np.random.normal(0,1./SNR, original.shape), self.x_noise: np.random.normal(0,1./SNR, original.shape)}
            generated = self.sess.run(self.outputs, feed_dict=feed_value)
            zeros = self.sess.run(self.outputs, feed_dict=feed_value1)
            return original, generated, zeros
        
       
        
        
        if target == 'NoiseAEMultiTime':
            index_ = random.randint(0, index)
            #print(self.dataset.test_img[0, :].shape)
            #print(self.standardize_amp(self.dataset.test_img[0, :]))
            original = self.standardize_amp(self.dataset.test_img[index_, :])[np.newaxis]
            original = shift_data(original)
            #original = self.scale_data_(original, -1./SNR-0.5, 1./SNR+0.5)
            noise = original + np.random.normal(0,1./SNR, original.shape)
            
            original_new_test = self.standardize_amp(self.dataset.signal_dict_new)[np.newaxis]
            original_new_test = shift_data(original_new_test)
            noise_new_test = original_new_test + np.random.normal(0,1./SNR, original_new_test.shape)
            
            ###
            std_noise = np.std(noise)
            noise /= std_noise
            #print(noise)
            #print(original + np.random.normal(0,1./SNR, original.shape))
            std_noise_new = np.std(noise_new_test)
            noise_new_test /= std_noise_new 
            ###
            
            #noise = self.scale_data_(noise, -1./SNR-0.5, 1./SNR+0.5)
            multi_noise = self.make_multi(noise)
            multi_noise_new_test = self.make_multi(noise_new_test)
            feed_value = {self.x_noise: multi_noise}
            #feed_value1 = {self.x_noise: self.scale_data_(self.make_multi(np.random.normal(0,1./SNR, original.shape)),
            #                                              -1./SNR-0.5, 1./SNR+0.5)}
            generate_noise = np.random.normal(0,1./SNR, original.shape)
            generate_noise /= np.std(generate_noise)
            feed_value1 = {self.x_noise: self.make_multi(generate_noise)}
            feed_value2 = {self.x_noise: multi_noise_new_test}
            generated = self.sess.run(self.outputs, feed_dict=feed_value)
            zeros = self.sess.run(self.outputs, feed_dict=feed_value1)
            generated_new_test = self.sess.run(self.outputs, feed_dict=feed_value2)
            return original/std_noise, generated, zeros, generated_new_test, original_new_test/std_noise_new
        
        
        if target == 'newMultiTime':
            index_ = random.randint(0, index)
            original = self.dataset.test_img[index_, :][np.newaxis]
            noise = np.random.normal(0,1./SNR, original.shape)
            multi_noise = self.make_multi(noise)
            noisySignal = original + noise
            multi_noisySignal = self.make_multi(noisySignal)
            #noise = scale(noise, 1)
            #original = scale(original, 1)
            feed_value = {self.x_noise_placeholder: self.make_multi(np.random.normal(0,1./SNR, original.shape)),
                          self.x_noisySignal_placeholder: multi_noisySignal}
            denoised = self.sess.run(self.original_outputs, feed_dict=feed_value)
            noisySignal_ = self.sess.run(self.noisySignal_outputs, feed_dict=feed_value)

            return original, denoised, noisySignal_, noisySignal
    
    
    
    
    
    
# contains special single layer
class network_layers(network_functions):
    def __init__(self, dataset, batch_size):
        network_functions.__init__(self, dataset, batch_size)
        
    
    ##########
    # convolutional layer with batch normalization and lrelu activation function
    ##########
    
    def conv2d_bn_lrelu(self, inputs, num_outputs, kernel_size, stride):
        conv = tf.contrib.layers.convolution2d(inputs, num_outputs, kernel_size, stride,
                                               weights_initializer=tf.random_normal_initializer(stddev=0.02),
                                               weights_regularizer=tf.contrib.layers.l2_regularizer(2.5e-5),
                                               activation_fn=tf.identity,padding='SAME')
        conv = tf.contrib.layers.batch_norm(conv)
        conv = self.network_functions.lrelu(conv)
        #conv = tf.nn.tanh(conv)
        return conv

    ##########
    # deconvolutional layer with batch normalization and lrelu activation function
    ##########

    def conv2d_t_bn_relu(self, inputs, num_outputs, kernel_size, stride):
        conv = tf.contrib.layers.convolution2d_transpose(inputs, num_outputs, kernel_size, stride,
                                                         weights_initializer=tf.random_normal_initializer(stddev=0.02),
                                                         weights_regularizer=tf.contrib.layers.l2_regularizer(2.5e-5),
                                                         activation_fn=tf.identity,padding='SAME')
        conv = tf.contrib.layers.batch_norm(conv)
        conv = self.network_functions.lrelu(conv)
        #conv = tf.nn.tanh(conv)
        return conv

        
    ##########
    # convolutional layer with batch normalization
    ##########
    

    def conv2d_t_bn(self, inputs, num_outputs, kernel_size, stride):
        conv = tf.contrib.layers.convolution2d_transpose(inputs, num_outputs, kernel_size, stride,
                                                         weights_initializer=tf.random_normal_initializer(stddev=0.02),
                                                         weights_regularizer=tf.contrib.layers.l2_regularizer(2.5e-5),
                                                         activation_fn=tf.identity,padding='SAME')
        conv = tf.contrib.layers.batch_norm(conv)
        return conv
    
    
    
    ##########
    # fully_connected layer with batch normalization and lrelu activation function
    ##########

    def fc_bn_lrelu(self, inputs, num_outputs):
        fc = tf.contrib.layers.fully_connected(inputs, num_outputs,
                                               weights_initializer=tf.random_normal_initializer(stddev=0.02),
                                               weights_regularizer=tf.contrib.layers.l2_regularizer(2.5e-5),
                                               activation_fn=tf.identity)
        fc = tf.contrib.layers.batch_norm(fc)
        fc = self.network_functions.lrelu(fc)
        #fc = tf.nn.tanh(fc)
        return fc
    
    
    ##########
    # fully_connected layer with batch normalization
    ##########


    def fc_bn_relu(inputs, num_outputs):
        fc = tf.contrib.layers.fully_connected(inputs, num_outputs,
                                               weights_initializer=tf.random_normal_initializer(stddev=0.02),
                                               weights_regularizer=tf.contrib.layers.l2_regularizer(2.5e-5),
                                               activation_fn=tf.identity)
        fc = tf.contrib.layers.batch_norm(fc)
        fc = tf.nn.relu(fc)
        #fc = tf.nn.tanh(fc)
        return fc

    

    


    
# contain large structures for a network 
class network_modules(network_layers):
    def __init__(self, dataset, batch_size):
        network_layers.__init__(self, dataset, batch_size)

    ##########
    # encoder module
    ##########
    def encoder(self, inputs, cell, hidden_num, is_bidirectional=False, activation_fn=tf.nn.tanh):
        
        '''
        Inputs:
        inputs: input tensor with shape [None, self.sample_rate] or [None, self.sample_rate, 1]
        cell: the basic LSTM cell in RNN that forms the stcuture of encoder. 
              should be a list of cell models in tensorflow libraries.             
        hidden_num: number of hideen units, should be written in list. Also decides the depth for encoder.
        is_bidirectional: a boolean, indicating if we would use tf.contrib.rnn.stack_bidirectional_dynamic_rnn function instead of the original tf.nn.dynamic_rnn funciton
        
        Notice that the cell length and hidden_num are two lists, and the function will make then equal to one with greater length
                      
        Output:
        z_codes for the bottle net layer with shape [None, hiddem_num[-1], 1]and the enc_states with is either tuple type or a signle state depending on is_bidireactional
        ''' 

            
            
        # check input shape
        if len(inputs.get_shape().as_list()) == 2:
            inputs = tf.expand_dims(inputs, axis=-1)
        
        # construct cell lists
        if len(cell) != len(hidden_num): # decide if the cell len is same as hidden len (they are lists)
            if len(cell) < len(hidden_num): # this is to duplicate cells to have same length a hidden_num
                cell_table = []
                for i in range(len(hidden_num)):
                    cell_table.append(cell[0])
                assert len(cell_table) == len(hidden_num)
                hidden_num_table = hidden_num
            elif len(cell) > len(hidden_num):
                hidden_num_table = []
                for i in range(len(cell)):
                    hidden_num_table.appen(hidden_num[0])
                assert len(hidden_num_table) == len(cell)
                cell_table = cell
            if is_bidirectional is True:
                cells_table1 = []
                cells_table2 = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table1.append(cell_table[i](hidden_num_table[i], activation=activation_fn))                
                    cells_table2.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                input_cells = {'bidirectionalcells1': cells_table1,
                               'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                    
            else:
                cells_table = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                input_cells = {'cells': rnn.MultiRNNCell(cells_table)} # output a cell list with different cell and differen hidden_num combined

        else:
            if len(cell) == len(hidden_num) and len(cell) > 1:
                if is_bidirectional is True:
                    cells_table1_diff = []
                    cells_table2_diff = []
                    for i in range(len(cell)):
                        cells_table1_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                        cells_table2_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1_diff,
                                   'bidirectionalcells2': cells_table2_diff}
                else:
                    cell_table = cell
                    hidden_num_table = hidden_num
                    cells_table_diff = []
                    for i in range(len(cell)):
                        cells_table_diff.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                    input_cells = {'cells': rnn.MultiRNNCell(cells_table_diff)}
           
            else:
                # happens when the cell and hidden_num only have one value
                # in each of the list: len(cell)==1, len(hidden_num)==1
                if is_bidirectional is True:
                    cells_table1 = []
                    cells_table2 = []
                    for i in range(max(len(cell), len(hidden_num))):
                        cells_table1.append(cell[i](hidden_num[i], activation=activation_fn))                
                        cells_table2.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1,
                                   'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                else:
                    cell_table = cell 
                    hidden_num_table = hidden_num  
                    input_cells = {'cells': cell_table[0](hidden_num_table[0], activation=activation_fn)}


        # where the actual calculation happens
        
        if is_bidirectional is True:
            z_codes, enc_state_bi1, enc_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(input_cells['bidirectionalcells1'],
                                                                                        input_cells['bidirectionalcells2'],
                                                                                        inputs, dtype=tf.float32, scope='enc')

            return z_codes, (enc_state_bi1, enc_state_bi2)
        else:
            #print(input_cells['cells'])
            z_codes, enc_state = tf.nn.dynamic_rnn(input_cells['cells'], inputs, dtype=tf.float32)
            return z_codes, enc_state
        
        
    ##########
    # decoder module
    ##########
    def decoder(self, inputs, cell, hidden_num, is_bidirectional=False, activation_fn=tf.nn.tanh):
        '''
        Inputs:
        inputs: input tensor with shape [None, self.sample_rate, hidden_num[-1]]
        cell: the basic LSTM cell in RNN that forms the stcuture of encoder. 
              should be a list of cell models in tensorflow libraries.             
        hidden_num: number of hideen units, should be written in list. Also decides the depth for encoder.
        is_bidirectional: a boolean, indicating if we would use tf.contrib.rnn.stack_bidirectional_dynamic_rnn function instead of the original tf.nn.dynamic_rnn funciton
        
        Notice that the cell length and hidden_num are two lists, and the function will make then equal to one with greater length
                      
        Output:
        outputs from decoder with shape [None, self.sample_rate, 1] and the enc_states with is either tuple type or a signle state depending on is_bidireactional
        
        '''       
        # check input shape
        if len(inputs.get_shape().as_list()) == 2:
            inputs = tf.expand_dims(inputs, axis=-1)
        
        # construct cell lists
        if len(cell) != len(hidden_num): # decide if the cell len is same as hidden len (they are lists)
            if len(cell) < len(hidden_num): # this is to duplicate cells to have same length a hidden_num
                cell_table = []
                for i in range(len(hidden_num)):
                    cell_table.append(cell[0])
                assert len(cell_table) == len(hidden_num)
                hidden_num_table = hidden_num
            elif len(cell) > len(hidden_num):
                hidden_num_table = []
                for i in range(len(cell)):
                    hidden_num_table.appen(hidden_num[0])
                assert len(hidden_num_table) == len(cell)
                cell_table = cell
            if is_bidirectional is True:
                cells_table1 = []
                cells_table2 = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table1.append(cell_table[i](hidden_num_table[i], activation=activation_fn))                
                    cells_table2.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table1.reverse()
                cells_table2.reverse()
                input_cells = {'bidirectionalcells1': cells_table1,
                               'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                    
            else:
                cells_table = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table.reverse()
                input_cells = {'cells': rnn.MultiRNNCell(cells_table)} # output a cell list with different cell and differen hidden_num combined

        else:
            if len(cell) == len(hidden_num) and len(cell) > 1:
                if is_bidirectional is True:
                    cells_table1_diff = []
                    cells_table2_diff = []
                    for i in range(len(cell)):
                        cells_table1_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                        cells_table2_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                    cells_table1_diff.reverse()
                    cells_table2_diff.reverse()
                    input_cells = {'bidirectionalcells1': cells_table1_diff,
                                   'bidirectionalcells2': cells_table2_diff}
                else:
                    cell_table = cell
                    hidden_num_table = hidden_num
                    cells_table_diff = []
                    for i in range(len(cell)):
                        cells_table_diff.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                    cells_table_diff.reverse()
                    input_cells = {'cells': rnn.MultiRNNCell(cells_table_diff)}
            else:
                # happens when the cell and hidden_num only have one value
                # in each of the list: len(cell)==1, len(hidden_num)==1
                if is_bidirectional is True:
                    cells_table1 = []
                    cells_table2 = []
                    for i in range(max(len(cell), len(hidden_num))):
                        cells_table1.append(cell[i](hidden_num[i], activation=activation_fn))                
                        cells_table2.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1,
                                   'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                else:
                    cell_table = cell 
                    hidden_num_table = hidden_num  
                    input_cells = {'cells': cell_table[0](hidden_num_table[0], activation=activation_fn)}


        if is_bidirectional is True:
            outputs, dec_state_bi1, dec_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(input_cells['bidirectionalcells1'],
                                                                input_cells['bidirectionalcells2'],
                                                                inputs, dtype=tf.float32)
            #bidirectional_cell1_final = [rnn.LSTMCell(1)]
            #bidirectional_cell2_final = [rnn.LSTMCell(1)]
            #outputs, dec_state_bi1, dec_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(bidirectional_cell1_final,
            #                                                                            bidirectional_cell2_final,
            #                                                                            outputs, dtype=tf.float32, scope='dec')
            #print(tf.Variable(tf.random_normal([tf.stack(tf.shape(outputs)[0]),
            #                                                   outputs.get_shape().as_list()[-1],
            #                                                   1])))
            
            weights_bidirectional_lastlayer = tf.get_variable('final_weights_bi',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,.8))
            biases_bidirectional_lastlayer = tf.get_variable('final_biases_bi', [1,],
                                                             initializer=tf.constant_initializer(0.3))

            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_bidirectional_lastlayer), biases_bidirectional_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            return outputs, (dec_state_bi1, dec_state_bi2)
        else:
            outputs, dec_state = tf.nn.dynamic_rnn(input_cells['cells'], inputs, dtype=tf.float32)
            weights_rnn_lastlayer = tf.get_variable('final_weights_rnn',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,.8))
            biases_rnn_lastlayer = tf.get_variable('final_biases_rnn', [1,],
                                                             initializer=tf.constant_initializer(0.3))
            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_rnn_lastlayer), biases_rnn_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            return outputs, dec_state
        
        
    ##########
    # decoder module no last layer
    ##########
    def decoder_nolast(self, inputs, cell, hidden_num, is_bidirectional=False, activation_fn=tf.nn.tanh):
        '''
        Inputs:
        inputs: input tensor with shape [None, self.sample_rate, hidden_num[-1]]
        cell: the basic LSTM cell in RNN that forms the stcuture of encoder. 
              should be a list of cell models in tensorflow libraries.             
        hidden_num: number of hideen units, should be written in list. Also decides the depth for encoder.
        is_bidirectional: a boolean, indicating if we would use tf.contrib.rnn.stack_bidirectional_dynamic_rnn function instead of the original tf.nn.dynamic_rnn funciton
        
        Notice that the cell length and hidden_num are two lists, and the function will make then equal to one with greater length
                      
        Output:
        outputs from decoder with shape [None, self.sample_rate, 1] and the enc_states with is either tuple type or a signle state depending on is_bidireactional
        
        '''       
        # check input shape
        if len(inputs.get_shape().as_list()) == 2:
            inputs = tf.expand_dims(inputs, axis=-1)
        
        # construct cell lists
        if len(cell) != len(hidden_num): # decide if the cell len is same as hidden len (they are lists)
            if len(cell) < len(hidden_num): # this is to duplicate cells to have same length a hidden_num
                cell_table = []
                for i in range(len(hidden_num)):
                    cell_table.append(cell[0])
                assert len(cell_table) == len(hidden_num)
                hidden_num_table = hidden_num
                #print(cell_table)
                #print(hidden_num_table)
            elif len(cell) > len(hidden_num):
                hidden_num_table = []
                for i in range(len(cell)):
                    hidden_num_table.appen(hidden_num[0])
                assert len(hidden_num_table) == len(cell)
                cell_table = cell
            if is_bidirectional is True:
                cells_table1 = []
                cells_table2 = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table1.append(cell_table[i](hidden_num_table[i], activation=activation_fn))                
                    cells_table2.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table1.reverse()
                cells_table2.reverse()
                input_cells = {'bidirectionalcells1': cells_table1,
                               'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                    
            else:
                cells_table = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table.reverse()
                input_cells = {'cells': rnn.MultiRNNCell(cells_table)} # output a cell list with different cell and differen hidden_num combined

        else:
            if len(cell) == len(hidden_num) and len(cell) > 1:
                if is_bidirectional is True:
                    cells_table1_diff = []
                    cells_table2_diff = []
                    for i in range(len(cell)):
                        cells_table1_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                        cells_table2_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                    cells_table1_diff.reverse()
                    cells_table2_diff.reverse()
                    input_cells = {'bidirectionalcells1': cells_table1_diff,
                                   'bidirectionalcells2': cells_table2_diff}
                else:
                    cell_table = cell
                    hidden_num_table = hidden_num
                    cells_table_diff = []
                    for i in range(len(cell)):
                        cells_table_diff.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                    cells_table_diff.reverse()
                    input_cells = {'cells': rnn.MultiRNNCell(cells_table_diff)}
            else:
                # happens when the cell and hidden_num only have one value
                # in each of the list: len(cell)==1, len(hidden_num)==1
                if is_bidirectional is True:
                    cells_table1 = []
                    cells_table2 = []
                    for i in range(max(len(cell), len(hidden_num))):
                        cells_table1.append(cell[i](hidden_num[i], activation=activation_fn))                
                        cells_table2.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1,
                                   'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                else:
                    cell_table = cell 
                    hidden_num_table = hidden_num  
                    input_cells = {'cells': cell_table[0](hidden_num_table[0], activation=activation_fn)}


        if is_bidirectional is True:
            outputs, dec_state_bi1, dec_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(input_cells['bidirectionalcells1'],
                                                                input_cells['bidirectionalcells2'],
                                                                inputs, dtype=tf.float32)
            '''
            weights_bidirectional_lastlayer = tf.get_variable('final_weights_bi',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,0.8))
            biases_bidirectional_lastlayer = tf.get_variable('final_biases_bi', [1,],
                                                             initializer=tf.constant_initializer(.3))
            
            
            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_bidirectional_lastlayer), biases_bidirectional_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            '''
            
            return outputs, (dec_state_bi1, dec_state_bi2)
        
        else:
            outputs, dec_state = tf.nn.dynamic_rnn(input_cells['cells'], inputs, dtype=tf.float32)

            '''
            weights_rnn_lastlayer = tf.get_variable('final_weights_rnn',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,0.8))
            biases_rnn_lastlayer = tf.get_variable('final_biases_rnn', [1,],
                                                             initializer=tf.constant_initializer(.3))
            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_rnn_lastlayer), biases_rnn_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            '''
            
            return outputs, dec_state
        
    
    
    ##########
    # stair decoder module
    ##########
    def stair_decoder(self, inputs, cell, hidden_num, states=None, is_bidirectional=False, activation_fn=tf.nn.tanh):
        '''
        Inputs:
        inputs: input tensor with shape [None, self.sample_rate, hidden_num[-1]]
        cell: the basic LSTM cell in RNN that forms the stcuture of encoder. 
              should be a list of cell models in tensorflow libraries.             
        hidden_num: number of hideen units, should be written in list. Also decides the depth for encoder.
        is_bidirectional: a boolean, indicating if we would use tf.contrib.rnn.stack_bidirectional_dynamic_rnn function instead of the original tf.nn.dynamic_rnn funciton
        
        Notice that the cell length and hidden_num are two lists, and the function will make then equal to one with greater length
                      
        Output:
        outputs from decoder with shape [None, self.sample_rate, 1] and the enc_states with is either tuple type or a signle state depending on is_bidireactional
        
        '''  
        assert states is not None
        # check input shape
        if len(inputs.get_shape().as_list()) == 2:
            inputs = tf.expand_dims(inputs, axis=-1)
        
        # construct cell lists
        if len(cell) != len(hidden_num): # decide if the cell len is same as hidden len (they are lists)
            if len(cell) < len(hidden_num): # this is to duplicate cells to have same length a hidden_num
                cell_table = []
                for i in range(len(hidden_num)):
                    cell_table.append(cell[0])
                assert len(cell_table) == len(hidden_num)
                hidden_num_table = hidden_num
            elif len(cell) > len(hidden_num):
                hidden_num_table = []
                for i in range(len(cell)):
                    hidden_num_table.appen(hidden_num[0])
                assert len(hidden_num_table) == len(cell)
                cell_table = cell
            if is_bidirectional is True:
                cells_table1 = []
                cells_table2 = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table1.append(cell_table[i](hidden_num_table[i], activation=activation_fn))                
                    cells_table2.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table1.reverse()
                cells_table2.reverse()
                input_cells = {'bidirectionalcells1': cells_table1,
                               'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                    
            else:
                cells_table = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table.reverse()
                input_cells = {'cells': rnn.MultiRNNCell(cells_table)} # output a cell list with different cell and differen hidden_num combined

        else:
            if len(cell) == len(hidden_num) and len(cell) > 1:
                if is_bidirectional is True:
                    cells_table1_diff = []
                    cells_table2_diff = []
                    for i in range(len(cell)):
                        cells_table1_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                        cells_table2_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                    cells_table1_diff.reverse()
                    cells_table2_diff.reverse()
                    input_cells = {'bidirectionalcells1': cells_table1_diff,
                                   'bidirectionalcells2': cells_table2_diff}
                else:
                    cell_table = cell
                    hidden_num_table = hidden_num
                    cells_table_diff = []
                    for i in range(len(cell)):
                        cells_table_diff.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                    cells_table_diff.reverse()
                    input_cells = {'cells': rnn.MultiRNNCell(cells_table_diff)}
            else:
                # happens when the cell and hidden_num only have one value
                # in each of the list: len(cell)==1, len(hidden_num)==1
                if is_bidirectional is True:
                    cells_table1 = []
                    cells_table2 = []
                    for i in range(max(len(cell), len(hidden_num))):
                        cells_table1.append(cell[i](hidden_num[i], activation=activation_fn))                
                        cells_table2.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1,
                                   'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                else:
                    cell_table = cell 
                    hidden_num_table = hidden_num  
                    input_cells = {'cells': cell_table[0](hidden_num_table[0], activation=activation_fn)}


        if is_bidirectional is True:
            outputs, dec_state_bi1, dec_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(input_cells['bidirectionalcells1'],
                                                                input_cells['bidirectionalcells2'],
                                                                inputs, states[0], states[1])
            #bidirectional_cell1_final = [rnn.LSTMCell(1)]
            #bidirectional_cell2_final = [rnn.LSTMCell(1)]
            #outputs, dec_state_bi1, dec_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(bidirectional_cell1_final,
            #                                                                            bidirectional_cell2_final,
            #                                                                            outputs, dtype=tf.float32, scope='dec')
            #print(tf.Variable(tf.random_normal([tf.stack(tf.shape(outputs)[0]),
            #                                                   outputs.get_shape().as_list()[-1],
            #                                                   1])))
            
            weights_bidirectional_lastlayer = tf.get_variable('final_weights_bi',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,.8))
            biases_bidirectional_lastlayer = tf.get_variable('final_biases_bi', [1,],
                                                             initializer=tf.constant_initializer(0.3))

            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_bidirectional_lastlayer), biases_bidirectional_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            return outputs, (dec_state_bi1, dec_state_bi2)
        else:
            outputs, dec_state = tf.nn.dynamic_rnn(input_cells['cells'], inputs, dtype=tf.float32, initial_state=states[0])
            weights_rnn_lastlayer = tf.get_variable('final_weights_rnn',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,.8))
            biases_rnn_lastlayer = tf.get_variable('final_biases_rnn', [1,],
                                                             initializer=tf.constant_initializer(0.3))
            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_rnn_lastlayer), biases_rnn_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            return outputs, dec_state
        
        
        
    ##########
    # encoder module with states
    ##########
    def states_encoder(self, inputs, cell, hidden_num, is_bidirectional=False, activation_fn=tf.nn.tanh):
        
        '''
        Inputs:
        inputs: input tensor with shape [None, self.sample_rate] or [None, self.sample_rate, 1]
        cell: the basic LSTM cell in RNN that forms the stcuture of encoder. 
              should be a list of cell models in tensorflow libraries.             
        hidden_num: number of hideen units, should be written in list. Also decides the depth for encoder.
        is_bidirectional: a boolean, indicating if we would use tf.contrib.rnn.stack_bidirectional_dynamic_rnn function instead of the original tf.nn.dynamic_rnn funciton
        
        Notice that the cell length and hidden_num are two lists, and the function will make then equal to one with greater length
                      
        Output:
        z_codes for the bottle net layer with shape [None, hiddem_num[-1], 1]and the enc_states with is either tuple type or a signle state depending on is_bidireactional
        ''' 

            
            
        # check input shape
        if len(inputs.get_shape().as_list()) == 2:
            inputs = tf.expand_dims(inputs, axis=-1)
        
        # construct cell lists
        if len(cell) != len(hidden_num): # decide if the cell len is same as hidden len (they are lists)
            if len(cell) < len(hidden_num): # this is to duplicate cells to have same length a hidden_num
                cell_table = []
                for i in range(len(hidden_num)):
                    cell_table.append(cell[0])
                assert len(cell_table) == len(hidden_num)
                hidden_num_table = hidden_num
            elif len(cell) > len(hidden_num):
                hidden_num_table = []
                for i in range(len(cell)):
                    hidden_num_table.appen(hidden_num[0])
                assert len(hidden_num_table) == len(cell)
                cell_table = cell
            if is_bidirectional is True:
                cells_table1 = []
                cells_table2 = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table1.append(cell_table[i](hidden_num_table[i], activation=activation_fn))                
                    cells_table2.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                input_cells = {'bidirectionalcells1': cells_table1,
                               'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                    
            else:
                cells_table = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                input_cells = {'cells': rnn.MultiRNNCell(cells_table)} # output a cell list with different cell and differen hidden_num combined

        else:
            if len(cell) == len(hidden_num) and len(cell) > 1:
                if is_bidirectional is True:
                    cells_table1_diff = []
                    cells_table2_diff = []
                    for i in range(len(cell)):
                        cells_table1_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                        cells_table2_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1_diff,
                                   'bidirectionalcells2': cells_table2_diff}
                else:
                    cell_table = cell
                    hidden_num_table = hidden_num
                    cells_table_diff = []
                    for i in range(len(cell)):
                        cells_table_diff.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                    input_cells = {'cells': rnn.MultiRNNCell(cells_table_diff)}
           
            else:
                # happens when the cell and hidden_num only have one value
                # in each of the list: len(cell)==1, len(hidden_num)==1
                if is_bidirectional is True:
                    cells_table1 = []
                    cells_table2 = []
                    for i in range(max(len(cell), len(hidden_num))):
                        cells_table1.append(cell[i](hidden_num[i], activation=activation_fn))                
                        cells_table2.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1,
                                   'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                else:
                    cell_table = cell 
                    hidden_num_table = hidden_num  
                    input_cells = {'cells': cell_table[0](hidden_num_table[0], activation=activation_fn)}


        # where the actual calculation happens
        
        if is_bidirectional is True:
            z_codes, enc_state_bi1, enc_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(input_cells['bidirectionalcells1'],
                                                                                        input_cells['bidirectionalcells2'],
                                                                                        inputs, dtype=tf.float32, scope='enc')

            return z_codes, (enc_state_bi1, enc_state_bi2)
        else:
            #print(input_cells['cells'])
            z_codes, enc_state = tf.nn.dynamic_rnn(input_cells['cells'], inputs, dtype=tf.float32)
            return z_codes, enc_state
        
        
        
    ##########
    # decoder module no last layer (stair)
    ##########
    def stair_decoder_nolast(self, inputs, cell, hidden_num, is_bidirectional=False, activation_fn=tf.nn.tanh, states=None):
        '''
        Inputs:
        inputs: input tensor with shape [None, self.sample_rate, hidden_num[-1]]
        cell: the basic LSTM cell in RNN that forms the stcuture of encoder. 
              should be a list of cell models in tensorflow libraries.             
        hidden_num: number of hideen units, should be written in list. Also decides the depth for encoder.
        is_bidirectional: a boolean, indicating if we would use tf.contrib.rnn.stack_bidirectional_dynamic_rnn function instead of the original tf.nn.dynamic_rnn funciton
        
        Notice that the cell length and hidden_num are two lists, and the function will make then equal to one with greater length
                      
        Output:
        outputs from decoder with shape [None, self.sample_rate, 1] and the enc_states with is either tuple type or a signle state depending on is_bidireactional
        
        '''    
        assert states is not None
        # check input shape
        if len(inputs.get_shape().as_list()) == 2:
            inputs = tf.expand_dims(inputs, axis=-1)
        
        # construct cell lists
        if len(cell) != len(hidden_num): # decide if the cell len is same as hidden len (they are lists)
            if len(cell) < len(hidden_num): # this is to duplicate cells to have same length a hidden_num
                cell_table = []
                for i in range(len(hidden_num)):
                    cell_table.append(cell[0])
                assert len(cell_table) == len(hidden_num)
                hidden_num_table = hidden_num
                #print(cell_table)
                #print(hidden_num_table)
            elif len(cell) > len(hidden_num):
                hidden_num_table = []
                for i in range(len(cell)):
                    hidden_num_table.appen(hidden_num[0])
                assert len(hidden_num_table) == len(cell)
                cell_table = cell
            if is_bidirectional is True:
                cells_table1 = []
                cells_table2 = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table1.append(cell_table[i](hidden_num_table[i], activation=activation_fn))                
                    cells_table2.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table1.reverse()
                cells_table2.reverse()
                input_cells = {'bidirectionalcells1': cells_table1,
                               'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                    
            else:
                cells_table = []
                for i in range(max(len(cell), len(hidden_num))):
                    cells_table.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                cells_table.reverse()
                input_cells = {'cells': rnn.MultiRNNCell(cells_table)} # output a cell list with different cell and differen hidden_num combined

        else:
            if len(cell) == len(hidden_num) and len(cell) > 1:
                if is_bidirectional is True:
                    cells_table1_diff = []
                    cells_table2_diff = []
                    for i in range(len(cell)):
                        cells_table1_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                        cells_table2_diff.append(cell[i](hidden_num[i], activation=activation_fn))
                    cells_table1_diff.reverse()
                    cells_table2_diff.reverse()
                    input_cells = {'bidirectionalcells1': cells_table1_diff,
                                   'bidirectionalcells2': cells_table2_diff}
                else:
                    cell_table = cell
                    hidden_num_table = hidden_num
                    cells_table_diff = []
                    for i in range(len(cell)):
                        cells_table_diff.append(cell_table[i](hidden_num_table[i], activation=activation_fn))
                    cells_table_diff.reverse()
                    input_cells = {'cells': rnn.MultiRNNCell(cells_table_diff)}
            else:
                # happens when the cell and hidden_num only have one value
                # in each of the list: len(cell)==1, len(hidden_num)==1
                if is_bidirectional is True:
                    cells_table1 = []
                    cells_table2 = []
                    for i in range(max(len(cell), len(hidden_num))):
                        cells_table1.append(cell[i](hidden_num[i], activation=activation_fn))                
                        cells_table2.append(cell[i](hidden_num[i], activation=activation_fn))
                    input_cells = {'bidirectionalcells1': cells_table1,
                                   'bidirectionalcells2': cells_table2} # output a dictionary with two cells used for bidirectional layers
                else:
                    cell_table = cell 
                    hidden_num_table = hidden_num  
                    input_cells = {'cells': cell_table[0](hidden_num_table[0], activation=activation_fn)}


        if is_bidirectional is True:
            outputs, dec_state_bi1, dec_state_bi2 = rnn.stack_bidirectional_dynamic_rnn(input_cells['bidirectionalcells1'],
                                                                input_cells['bidirectionalcells2'],
                                                                inputs, states[0], states[1])
            '''
            weights_bidirectional_lastlayer = tf.get_variable('final_weights_bi',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,0.8))
            biases_bidirectional_lastlayer = tf.get_variable('final_biases_bi', [1,],
                                                             initializer=tf.constant_initializer(.3))
            
            
            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_bidirectional_lastlayer), biases_bidirectional_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            '''
            
            return outputs, (dec_state_bi1, dec_state_bi2)
        
        else:
            outputs, dec_state = tf.nn.dynamic_rnn(input_cells['cells'], inputs, dtype=tf.float32)

            '''
            weights_rnn_lastlayer = tf.get_variable('final_weights_rnn',
                                                              [outputs.get_shape().as_list()[-1],1],
                                                             initializer=tf.random_normal_initializer(0.,0.8))
            biases_rnn_lastlayer = tf.get_variable('final_biases_rnn', [1,],
                                                             initializer=tf.constant_initializer(.3))
            outputs = tf.reshape(outputs, [-1, outputs.get_shape().as_list()[-1]])
            outputs = tf.add(tf.matmul(outputs, weights_rnn_lastlayer), biases_rnn_lastlayer)
            outputs = tf.reshape(outputs, [-1, self.sample_rate, 1])
            '''
            
            return outputs, dec_state
        
    
        
    