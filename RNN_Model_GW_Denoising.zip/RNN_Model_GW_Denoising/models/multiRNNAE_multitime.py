import tensorflow as tf
import numpy as np
from tensorflow.contrib import rnn
from sklearn.preprocessing import scale
import tensorflow.contrib.slim as slim
import random
from modules.modules import network_modules
import copy


class multiLSTMAutoencoderMultiTime(network_modules):
    def __init__(self, hidden_num, dataset, batch_size=30, name=None,
                 cell=None, learning_rate=0.0001, latent_dim=None, seq_len_per_timestep=3,is_restore=False,restore_path=None):

        assert cell is not None
        assert name is not None
        assert latent_dim is not None

        network_modules.__init__(self, dataset, batch_size)

        if name is None or name == '':
            self.name = "model_for_%s" % dataset.name
        else:
            self.name = name
        
        self.is_restore = is_restore
        self.restore_path = restore_path
        if self.is_restore is True:
            assert self.restore_path is not None
        self.hidden_num = hidden_num  # must be a list
        self.cell = cell  # must be a list
        self.nb_hidden = len(self.hidden_num)  # number of hidden layers
        self.dataset = dataset
        self.batch_size = batch_size
        self.data_dims = self.dataset.data_dims
        self.sample_rate = self.data_dims[-2]
        self.learning_rate = learning_rate
        self.iteration = 0
        self.latent_dim = latent_dim
        self.seq_len_per_timestep = seq_len_per_timestep
        self.build_model()
        self.merged_summary = tf.summary.merge_all()
        if self.is_restore is True:
            self.restore_network()
        else:
            # Set restart=True to not ignore previous checkpoint and restart training
            self.init_network(restart=True)
            self.print_network()
            # Set read_only=True to not overwrite previous checkpoint
        self.read_only = False            
        



        # self.batch_num = self.batch_size
        # self.elem_num = self.data_dims[1]

    ##########
    # build structure
    ##########

    def build_model(self):

        x_original = tf.placeholder(tf.float32, [None, self.sample_rate], name='input_original')

        # TODO: if bidirectional, needs to double the last dimension
        # random_latent = tf.placeholder(tf.float32, [None, self.hidden_num[-1]], name='latent_variable')
        x_noise = tf.placeholder(tf.float32, [None, self.sample_rate, self.seq_len_per_timestep], name='noise')

        noise = x_noise
        
        original = tf.expand_dims(x_original, -1)
        
        with tf.variable_scope('conv_enc'):  
            noise = tf.expand_dims(noise, -1)
            noise = tf.transpose(noise, [0,1,3,2])
            noise = slim.conv2d(noise, 16, [4,1])
            noise = tf.transpose(noise, [0,1,3,2])
            noise = tf.squeeze(noise, -1)
        
        
        
        with tf.variable_scope('encoder') as enc:
            enc_outputs, enc_states = self.encoder(noise,
                                                   copy.deepcopy(self.cell), self.hidden_num,
                                                   is_bidirectional=True,
                                                   activation_fn=tf.nn.tanh)
            
            #print(enc_outputs.get_shape())
            
            
        with tf.variable_scope('conv_dec'):
            enc_outputs = tf.expand_dims(enc_outputs, -1)
            enc_outputs = tf.transpose(enc_outputs, [0, 1, 3, 2])
            enc_outputs = slim.conv2d(enc_outputs, 128, [4,1])
            enc_outputs = tf.transpose(enc_outputs, [0,1,3,2])
            enc_outputs = tf.squeeze(enc_outputs, -1)

        with tf.variable_scope('decoder') as dec:
            outputs, dec_states = self.decoder(enc_outputs,
                                               copy.deepcopy(self.cell), self.hidden_num,
                                               is_bidirectional=True,
                                               activation_fn=tf.nn.tanh)
            
            
        
        #with tf.variable_scope('decoder1'):
        #    outputs, dec_states = self.stair_decoder(outputs_,
        #                                       copy.deepcopy(self.cell), self.hidden_num,
        #                                       is_bidirectional=True,
        #                                       activation_fn=tf.nn.tanh, states=dec_states_)
       
            
        
        
        scalars = tf.Variable(tf.constant(1.,tf.float32, [1]))
        outputs = outputs * scalars
        
        loss = tf.reduce_mean(tf.square(original - outputs), keep_dims=False)
        #loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=outputs, labels=tf.nn.sigmoid(original)),
        #                                       keep_dims=False)
        
        


        # generate necessariy self.variables for global use

        self.loss = loss
        self.x_original_placeholder = x_original
        self.outputs = outputs
        self.x_noise = x_noise
        # self.random_latent = random_latent
        # self.output_random = output_random
        
        
        
        
        
        #global_step = tf.Variable(50000, trainable=False)
        #self.learning_rate = tf.train.exponential_decay(self.learning_rate, global_step,
        #                                   1000, 0.95, staircase=True)
        self.train_op = tf.train.AdamOptimizer(self.learning_rate).minimize(self.loss)
        
        
        # writing summaries
        tf.summary.scalar('MSE loss', self.loss)
        

    def train(self, batch_original, batch_noise):
        self.iteration += 1
        feed_dict = {self.x_original_placeholder: batch_original, self.x_noise: batch_noise}
        _, train_return = self.sess.run([self.train_op, self.loss],
                                        feed_dict=feed_dict)
        if self.iteration % 100 == 0:
            self.save_network()
        if self.iteration % 20 == 0:
            # because there is not any recorder for the structure currently
            summary = self.sess.run(self.merged_summary, feed_dict=feed_dict)
            self.writer.add_summary(summary, self.iteration)
        return train_return







