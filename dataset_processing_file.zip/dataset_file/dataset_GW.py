from dataset import *
import math, os
from glob import glob
import numpy as np
import scipy.misc as misc
from matplotlib import pyplot as plt
import h5py
from scipy.signal import resample
import operator

class GWDataset(Dataset):
    def __init__(self, crop=True, data_dims=[1,8192,1], make_multiple_timesteps=False,  seq_len_per_timestep=3):
        Dataset.__init__(self)
        self.data_files = h5py.File('/home/hongyu.shen/data/M1/EOB-M1.h5','r')
        self.make_multiple_timesteps = make_multiple_timesteps
        self.seq_len_per_timestep = seq_len_per_timestep
        self.data_dims = data_dims
        self.resample_data()
        self.train_test_index()
        self.make_multi()
        self.train_img = self.data_files[self.train_index,:]
        self.test_img = self.data_files[self.test_index,:]
        self.datamin = self.train_img.min()
        self.datamax = self.train_img.max()
        self.train_size = self.train_img.shape[0]
        self.test_size = len(self.data_files) - self.train_size
        self.train_idx = 0
        self.test_idx = 0
        self.train_cache = np.ndarray((self.train_size,)+ tuple(self.data_dims), dtype=np.float32)
        self.train_cache_top = 0
        self.train_cache_mass = np.ndarray((self.train_size,1), dtype=np.float32)
        self.train_cache_top_mass = 0
        self.test_cache = np.ndarray((self.train_size,)+ tuple(self.data_dims), dtype=np.float32)
        self.test_cache_top = 0
        self.range = [-1.0, 1.0]
        self.is_crop = crop
        self.name = "GW"
        

    """ Return [batch_size, 1, 8192, 1] data array by default"""
    def next_batch(self, batch_size):
        # sample_files = self.data[0:batch_size]
        prev_idx = self.train_idx
        self.train_idx += batch_size
        if self.train_idx > self.train_size:
            self.train_idx = batch_size
            prev_idx = 0

        if self.train_idx < self.train_cache_top:
            #print(np.reshape(self.train_cache[prev_idx:self.train_idx, :, :, :], (batch_size, self.data_dims[-2])).shape)
            return np.reshape(self.train_cache[prev_idx:self.train_idx, :, :, :], (batch_size, self.data_dims[-2]))
        else:
            sample_files = self.train_img[prev_idx:self.train_idx,:]
            #sample = [self.get_image(sample_file, self.is_crop) for sample_file in sample_files]
            sample_images = sample_files
            sample_images_reshaped = np.reshape(sample_images, (batch_size,) + tuple(self.data_dims))
            #print(sample_images.shape)
            #print(np.reshape(sample_images, (batch_size,) + tuple(self.data_dims)).shape)
            #sample_images = np.array(sample).astype(np.float32)
            self.train_cache[prev_idx:self.train_idx] = sample_images_reshaped
            self.train_cache_top = self.train_idx
            return sample_images
        
        
    def next_batch_reg(self, batch_size):
        # sample_files = self.data[0:batch_size]
        prev_idx = self.train_idx
        self.train_idx += batch_size
        if self.train_idx > self.train_size:
            self.train_idx = batch_size
            prev_idx = 0

        if self.train_idx < self.train_cache_top:
            #print(np.reshape(self.train_cache[prev_idx:self.train_idx, :, :, :], (batch_size, self.data_dims[-2])).shape)
            return np.reshape(self.train_cache[prev_idx:self.train_idx, :, :, :], (batch_size, self.data_dims[-2])), self.train_cache_mass[prev_idx:self.train_idx,:]
        else:
            sample_files = self.train_img[prev_idx:self.train_idx,:]
            #sample = [self.get_image(sample_file, self.is_crop) for sample_file in sample_files]
            sample_images = sample_files
            sample_images_reshaped = np.reshape(sample_images, (batch_size,) + tuple(self.data_dims))
            #print(sample_images.shape)
            #print(np.reshape(sample_images, (batch_size,) + tuple(self.data_dims)).shape)
            #sample_images = np.array(sample).astype(np.float32)
            self.train_cache[prev_idx:self.train_idx] = sample_images_reshaped
            self.train_cache_top = self.train_idx
            
            # for mass ratio
            
            sample_massRatio = self.MassRatio[prev_idx:self.train_idx, :]
            self.train_cache_mass[prev_idx:self.train_idx] = sample_massRatio
            self.train_cache_top = self.train_idx
            
            return sample_images, sample_massRatio

    def next_test_batch(self, batch_size):
        prev_idx = self.test_idx
        self.test_idx += batch_size
        if self.test_idx > self.test_size:
            self.test_idx = batch_size
            prev_idx = 0

        if self.test_idx < self.test_cache_top:
            return self.test_cache[prev_idx:self.test_idx, :, :, :]
        else:
            sample_files = self.test_img[prev_idx:self.test_idx]
            sample = [self.get_image(sample_file, self.is_crop) for sample_file in sample_files]
            sample_images = np.array(sample).astype(np.float32)
            self.test_cache[prev_idx:self.test_idx] = sample_images
            self.test_cache_top = self.test_idx
            return sample_images

    def batch_by_index(self, batch_start, batch_end):
        sample_files = self.data_files[batch_start:batch_end]
        sample = [self.get_image(sample_file) for sample_file in sample_files]
        sample_images = np.array(sample).astype(np.float32)
        return sample_images
    
    def resample_data(self):
        key1, key2 = self.data_files.keys()
        MassRatio = np.array(self.data_files[key1])
        hPlus = np.array(self.data_files[key2])
        self.MassRatio = MassRatio[:,np.newaxis]
        #print(self.MassRatio.shape)
        self.hPlus = hPlus
        #hPlus = hPlus[:,-39985:,:]
        hPlus = hPlus[:,-2000:-500,:]
        sample_rate = self.data_dims[-2]
        self.tmp_data_files = np.zeros([hPlus.shape[0], sample_rate])
        for i in range(hPlus.shape[0]):
            self.tmp_data_files[i,:] = resample(hPlus[i,:,1],sample_rate)
        self.data_files = self.tmp_data_files
        print(self.data_files.shape)
        
        
    def make_multi(self):
        if self.make_multiple_timesteps is True:
            dataFile = self.data_files
            num_of_zeros = (self.seq_len_per_timestep - 1) / 2
            extended_dims = [self.data_files.shape[0], self.data_files.shape[1], ] + [self.seq_len_per_timestep]
            tmpFile = np.zeros(extended_dims)
            for k in range(self.data_dims[0]):
                for i in range(self.data_dims[-2]):
                    if i < num_of_zeros:
                        tmpFile[k, i, :] = np.hstack((np.zeros([num_of_zeros-i]),
                                                      dataFile[k, :(self.seq_len_per_timestep-num_of_zeros+i)]))
                    elif i >= num_of_zeros and i < (self.data_dims[-2]-num_of_zeros-1):
                        tmpFile[k, i, :] = dataFile[k, (i-num_of_zeros):(i + num_of_zeros + 1)]    
                    elif i > (self.data_dims[-2]-num_of_zeros-1):
                        tmpFile[k, i, :] = np.hstack((dataFile[k, (i-num_of_zeros):], 
                                                     np.zeros([num_of_zeros-(self.data_dims[-2]-1-i)])))
            self.data_files = tmpFile
        else:
            pass
        
        
        
    def train_test_index(self):
        A = np.arange(0,(len(self.data_files)-1),5)
        B = np.arange(len(self.data_files))
        condition = map(lambda x: True if x not in A else False, B)
        self.train_index = np.asarray(condition)
        self.test_index = np.asarray(map(operator.not_, condition))
        self.trainMass = self.MassRatio[self.train_index,:]
        self.testMass = self.MassRatio[self.test_index,:]
        
   
    def display_noise_signal(self,number_of_index=0):
            # plot noise

            # SNR=0.5
            plt.subplot(221)
            plt.plot(self.data_files[number_of_index,:]  + np.random.normal(0,2,[self.data_files.shape[1]]))
            plt.plot(self.data_files[number_of_index,:])
            # SNR=1
            plt.subplot(222)
            plt.plot(self.data_files[number_of_index,:] + np.random.normal(0,1,[self.data_files.shape[1]]))
            plt.plot(self.data_files[number_of_index,:])
            # SNR=5
            plt.subplot(223)
            plt.plot(self.data_files[number_of_index,:] + np.random.normal(0,0.2,[self.data_files.shape[1]]))
            plt.plot(self.data_files[number_of_index,:])
            # SNR=20
            plt.subplot(224)
            plt.plot(self.data_files[number_of_index,:] + np.random.normal(0,0.05,[self.data_files.shape[1]]))
            plt.plot(self.data_files[number_of_index,:])
            
            plt.show()
        

    @staticmethod
    def get_image(image_path, is_crop=True):
        image = GWDataset.transform(misc.imread(image_path).astype(np.float), is_crop=is_crop)
        return image

    @staticmethod
    def center_crop(x, crop_h, crop_w=None, resize_w=64):
        if crop_w is None:
            crop_w = crop_h
        h, w = x.shape[:2]
        j = int(round((h - crop_h) / 2.))
        i = int(round((w - crop_w) / 2.))
        return misc.imresize(x[j:j + crop_h, i:i + crop_w],
                                   [resize_w, resize_w])

    @staticmethod
    def full_crop(x):
        if x.shape[0] <= x.shape[1]:
            lb = int((x.shape[1] - x.shape[0]) / 2)
            ub = lb + x.shape[0]
            x = misc.imresize(x[:, lb:ub], [64, 64])
        else:
            lb = int((x.shape[0] - x.shape[1]) / 2)
            ub = lb + x.shape[1]
            x = misc.imresize(x[lb:ub, :], [64, 64])
        return x

    @staticmethod
    def transform(image, npx=108, is_crop=True, resize_w=64):
        # npx : # of pixels width/height of image
        if is_crop:
            cropped_image = GWDataset.center_crop(image, npx, resize_w=resize_w)
        else:
            cropped_image = GWDataset.full_crop(image)
        return np.array(cropped_image) / 127.5 - 1.

    """ Transform image to displayable """
    def display(self, image):
        rescaled = np.divide(image + 1.0, 2.0)
        return np.clip(rescaled, 0.0, 1.0)

    def reset(self):
        self.idx = 0


if __name__ == '__main__':
    dataset = GWDataset()
    while True:
        batch = dataset.next_batch(100)
        print(batch.shape)
        plt.imshow(dataset.display(batch[0]))
        plt.show()